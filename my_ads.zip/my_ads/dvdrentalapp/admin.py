from django.contrib import admin
from .models import Customer, Film, Staff
# Register your models here.
class CustomerAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "last_update")

class FilmAdmin(admin.ModelAdmin):
    list_display = ("title", "release_year", "last_update")

class StaffAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "last_update")

admin.site.register(Staff, StaffAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(Film, FilmAdmin)
