"""
# Aluna: Roberta Nunes da Rocha Brandao - 00020847
"""
from django.urls import path
from . import views

urlpatterns = [
path('', views.showHome, name='showhome'),
 path('customer/', views.customer, name='mycustomer'),
 path('categories/', views.list_category, name='myCategory'),
 path('add_category/', views.add_category, name='addCategory'),
 path('detalhes/<int:id>', views.detalhes, name='myDetalhe'),
 path('payments/<int:id>', views.payment, name='myPayment'),
 path('edit_customer/<int:customer_id>/', views.edit_customer, name='edit_customer'),
 path('edit_payment/<int:customer_id>/<int:payment_id>/', views.edit_payment, name='edit_payment'),
 path('cadastrar_usuario', views.cadastrar_usuario, name='cadastrar_usuario'),
 path('salva', views.salva, name='salva'),
 path('logar_usuario', views.logar_usuario, name='logar_usuario'),
 path('logado', views.logado, name='logado'),
 # prova 1 bim
 # Aluna: Roberta Nunes da Rocha Brandao - 00020847
 path('films/', views.list_films, name='myFilms'),
 path('filmactor/<int:id>', views.film_actor, name='myFilmActor'),
 path('actor/<int:id>', views.actor, name='myActor'),
 ]