"""
# Aluna: Roberta Nunes da Rocha Brandao - 00020847
"""

from django.http import HttpResponse
from django.template import loader
from django.utils import timezone
from .models import Customer, Rental, Payment, Category, Film, FilmActor, Actor
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate, login
from .forms import CustomerForm

def showHome(request):
    template = loader.get_template('home.html')
    return HttpResponse(template.render({}, request))


def customer(request):
    searchname = request.GET.get('query','')

    if searchname:
        mycustomers = Customer.objects.filter(first_name__contains=searchname).values()
    else:
        mycustomers = Customer.objects.all().values()

    template = loader.get_template('all_customers.html')
    context = {
        'mycustomer': mycustomers,
        'query_result': searchname,
    }
    return HttpResponse(template.render(context, request))

def list_category(request):
    myCategories = Category.objects.all().values()
    template = loader.get_template('all_categories.html')
    context = {
        'myCategories': myCategories,
    }
    return HttpResponse(template.render(context, request))

def add_category(request):
    if request.method == "POST":
        name = request.POST.get("name")
        category = Category(name=name, last_update=timezone.now())
        category.save()
        return redirect('/categories')
    return render(request, 'add_category.html')

def edit_customer(request, customer_id):
    customer = get_object_or_404(Customer, pk=customer_id)
    if request.method == "POST":
        customer.first_name = request.POST.get('first_name')
        customer.last_name = request.POST.get('last_name')
        customer.email = request.POST.get('email')
        customer.save()
        return redirect('/customer')
    return render(request, 'edit_customer.html', {'customer': customer})

def detalhes(request, id):
    myDetalhes = Rental.objects.filter(customer_id=id)
    customer = get_object_or_404(Customer, pk=id)

    template = loader.get_template('detalhes.html')
    context = {
        'myDetalhe' : myDetalhes,
        'customer_name' : f"{customer.first_name} {customer.last_name}",
        'customer_id': customer.customer_id,
    }
    return HttpResponse(template.render(context, request))

def payment(request, id):
    searchname = request.GET.get('query','')

    if searchname:
        myPayments = Payment.objects.filter(customer_id=id, payment_id=searchname)
    else:
        myPayments = Payment.objects.filter(customer_id=id)

    customer = get_object_or_404(Customer, pk=id)

    template = loader.get_template('payments.html')
    context = {
        'myPayment' : myPayments,
        'customer_name' : f"{customer.first_name} {customer.last_name}",
        'customer_id': customer.customer_id,
    }
    return HttpResponse(template.render(context, request))

def edit_payment(request, customer_id, payment_id):
    payment = get_object_or_404(Payment, pk=payment_id)
    if request.method == "POST":
        payment.amount = request.POST.get('amount')
        payment.save()
        return redirect(f"/payments/{customer_id}")
    return render(request, 'edit_payment.html', {'payment': payment})


def salva(request):
    return render(request, 'salva.html')

def cadastrar_usuario(request):
    if request.method == "POST":
        form_usuario = UserCreationForm(request.POST)
        if form_usuario.is_valid():
            form_usuario.save()
            return redirect('salva')
    else:
        form_usuario = UserCreationForm()
    return render(request, 'cadastro.html', {'form': form_usuario})

def salva(request):
    return render(request, 'salva.html')

"""
# para terminar depois a aula de forms
def customer_form_view(request):
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid
"""

def logar_usuario(request):
    msg = ''
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        usuario = authenticate(request, username=username, password=password)
        if usuario is not None:
            login(request, usuario)
            return redirect('logado')
        else:
            form_login = AuthenticationForm()
            msg = 'error com' + usuario
    else:
        form_login = AuthenticationForm()
        msg = 'error de post:' + request.method

    return render(request, 'login.html', {'form': form_login, 'msg': msg})

def logado(request):
    return render(request, 'logado.html')

# prova 1 bim
# Aluna: Roberta Nunes da Rocha Brandao - 00020847

def list_films(request):
    myFilms = Film.objects.all().values()
    template = loader.get_template('all_films.html')
    context = {
        'myFilms': myFilms,
    }
    return HttpResponse(template.render(context, request))

def film_actor(request, id):
    myfilmActor = FilmActor.objects.filter(film_id=id)

    template = loader.get_template('film_actor.html')
    context = {
        'myFilmActor' : myfilmActor,
        'myfilmId': id,
    }
    return HttpResponse(template.render(context, request))

def actor(request, id):
    myActor = get_object_or_404(Actor, pk=id)

    template = loader.get_template('actor.html')
    context = {
        'FirstName' : myActor.first_name,
        'LastName' : myActor.last_name,
        'ActorId': myActor.actor_id,
        'LastUpdate': myActor.last_update,
    }
    return HttpResponse(template.render(context, request))